package torrehanoia3;

import javax.swing.JOptionPane;


public class TorreHanoiA3 {



    public static void main(String[] args) {
      
        
      JOptionPane.showMessageDialog(null, "Esse é o jogo de Torre de Hanói, nesse jogo vai ser apresentado à você 3 pinos, o pino 1 vem preenchido com uma torre de discos e os 2 outros pinos começam vazios,  você precisa movimentar os discos com o objetivo de\n formar uma torre de discos no pino 2 ou 3, a cada rodada do jogo você responde duas perguntas, na primeira você responde com o número do pino que vai ser retirado o disco (sempre é retirado o disco no topo),\n e na segunda pergunta você diz em qual pino o disco será colocado, se o pino 2 ou 3 estiverem completos o jogo é concluído e é mostrado o número de tentativas utilizadas.\n E uma regra muito importante uma Torre de Hanói é formada por discos maiores embaixo dos menores então não é possível colocar o disco 1 embaixo do disco 2.");  
        int numeroDiscos = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha a dificuldade: Molezinha - 3 discos, Interessante - 4 discos, desafiador - 5 discos, SENHOR RACIOCÍNIO LÓGICO - 6 discos"));
        Pilha pino1 = new Pilha(numeroDiscos);
        Pilha pino2 = new Pilha(numeroDiscos);
        Pilha pino3 = new Pilha(numeroDiscos);  
        if(numeroDiscos == 3){
            pino1.push(3);
            pino1.push(2);
            pino1.push(1);
        }
        else if(numeroDiscos == 4){
            pino1.push(4);
            pino1.push(3);
            pino1.push(2);
            pino1.push(1);
        }
        else if(numeroDiscos == 5){
            pino1.push(5);
            pino1.push(4);
            pino1.push(3);
            pino1.push(2);
            pino1.push(1);
        }
        else if(numeroDiscos == 6){
            pino1.push(6);
            pino1.push(5);
            pino1.push(4);
            pino1.push(3);
            pino1.push(2);
            pino1.push(1);
        }
        int tentativas = 0;
        int  aux = 0;
        while(!pino2.isFull() && !pino3.isFull() && aux==0){
        int topoHanoi = 0;
        int escolhaRetirada = Integer.parseInt(JOptionPane.showInputDialog("Escolha de qual pino você quer retirar um disco -"+ pino1.toString(" pino 1: ")+pino2.toString(" pino 2: ") + pino3.toString(" pino 3: ")));
            if(escolhaRetirada == 1){
                topoHanoi = pino1.peek();
                pino1.pop();
            }
            else if(escolhaRetirada == 2){
                topoHanoi = pino2.peek();
                pino2.pop();     
            }
            else if(escolhaRetirada == 3){
                topoHanoi = pino3.peek();
                pino3.pop();
            }
        int escolhaDestino = Integer.parseInt(JOptionPane.showInputDialog("Digite o número do pino que você quer colocar esse disco -"+ pino1.toString(" pino 1: ")+pino2.toString(" pino 2: ") + pino3.toString(" pino 3: ")));   
                if(escolhaDestino == 1){
                    aux = pino1.push(topoHanoi);
                }
                else if(escolhaDestino == 2){
                    aux = pino2.push(topoHanoi);
                }
                else if(escolhaDestino == 3){
                    aux = pino3.push(topoHanoi);
                }
        
          
            tentativas++;
            JOptionPane.showMessageDialog(null, "Discos no "+pino1.toString("pino1: "));
            JOptionPane.showMessageDialog(null, "Discos no "+pino2.toString("pino2 "));
            JOptionPane.showMessageDialog(null, "Discos no "+pino3.toString("pino3 "));
            JOptionPane.showMessageDialog(null, "Seu número de tentativas atual é de: "+tentativas+ " tentativa(s)");
            System.out.println(pino1.toString("pino 1:"));
            System.out.println(pino2.toString("pino 2:"));
            System.out.println(pino3.toString("pino 3:"));
            System.out.println("número de tentativas: "+tentativas); 
            if(pino2.isFull() || pino3.isFull()){
                JOptionPane.showMessageDialog(null, "MUITO BEM! Você empilhou a Torre de Hanói em um total de "+tentativas+" tentativas"); 
                System.out.println("MUITO BEM! Você empilhou a Torre de Hanói em um o total de "+tentativas+" tentativas");
            }
        } 
        } 
    }
    
    